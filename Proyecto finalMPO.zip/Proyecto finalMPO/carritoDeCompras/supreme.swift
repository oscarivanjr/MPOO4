//
//  supreme.swift
//  carritoDeCompras
//
//  Created by Oscar Ivan on 01/10/18.
//  Copyright © 2018 Oscar Ivan. All rights reserved.
//

import Foundation
struct infoDelProducto {
    var nombre: String
    var imagen: String
    var descripcion: String
    var precio: Double
    
}
