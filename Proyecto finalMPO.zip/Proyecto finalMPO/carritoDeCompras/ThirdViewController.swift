//
//  ThirdViewController.swift
//  carritoDeCompras
//
//  Created by Oscar Ivan on 04/10/18.
//  Copyright © 2018 Oscar Ivan. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet weak var total: UILabel!
    @IBOutlet weak var listacarro: UITableView!
    
    var total1: Double = 0
    
    //weak var total: UILabel!{
        //var total: Int
        
    //}
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return compra.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell1 = tableView.dequeueReusableCell(withIdentifier: "celdados", for: indexPath)
        cell1.textLabel?.text = compra[indexPath.row].nombre
        return cell1
        
    }
    
   var compra = [infoDelProducto]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for i in compra{
            
           total1 = i.precio + total1
            
        }
        total.text = "\(total1)"
        
        
        
        
        

        // Do any additional setup after loading the view.
    }

   
    }
    

    

