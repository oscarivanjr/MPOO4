//
//  ViewController.swift
//  carritoDeCompras
//
//  Created by Oscar Ivan on 01/10/18.
//  Copyright © 2018 Oscar Ivan. All rights reserved.
// este es el actual

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tabla: UITableView!
    
    var catalogo = [infoDelProducto]()
    
    var carrito = [infoDelProducto]()
    
    
     override func viewDidLoad(){
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        catalogo.append(infoDelProducto(nombre: "Chamarra", imagen: "chamarra1", descripcion: "chaqueta de piel de perro", precio: 300.00))
        catalogo.append(infoDelProducto(nombre: "pantalon", imagen: "pantalon1", descripcion: "de seda", precio: 90.00))
        catalogo.append(infoDelProducto(nombre: "camisa", imagen: "camisa1", descripcion: "de seda y oro", precio: 159.80))
        
      }
   

    
        @IBAction func unwindToMain(unwindSegue: UIStoryboardSegue){
            
        }
    
    
    
    
    
    

        //@IBOutlet weak var carrito: UILabel!
        

    
    
    
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return catalogo.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "cellone", for: indexPath)
        cell.textLabel?.text = catalogo[indexPath.row].nombre
        return cell
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        // Alumno despistado, aqui debe crear tu indexPath
        let indexPath2 = tabla.indexPathForSelectedRow
        if (segue.identifier == "nodo1"){
            let destination = segue.destination as! SecondViewController
            destination.selecionado = catalogo[(indexPath2?.row)!] //productos[indexPath.row]
        }
        
        if (segue.identifier == "nodo2"){
            let destination2 = segue.destination as! ThirdViewController
            destination2.compra = carrito
        }
        
    }
    

    @IBAction func unwindFromSecondVC(_ segue: UIStoryboardSegue) {
        
        if let origin = segue.source as? SecondViewController{
            let data = origin.selecionado
            let data2 = origin.contador
           if data2 == 0 { return }
            
            for _ in 0..<data2 {
                
                carrito.append(data!)
                
            }
        }
        //añadir.contad
        
        print(carrito)
        print("_________________________")
    }
    
    

    


}

