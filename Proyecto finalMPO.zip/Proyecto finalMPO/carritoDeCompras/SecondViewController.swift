//
//  SecondViewController.swift
//  carritoDeCompras
//
//  Created by Oscar Ivan on 01/10/18.
//  Copyright © 2018 Oscar Ivan. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    @IBOutlet weak var imageSup: UIImageView!
    
    @IBOutlet weak var nombreProducto: UILabel!
    
    @IBOutlet weak var precioProducto: UILabel!
    @IBOutlet weak var descripcionProducto: UILabel!
    
    
    var selecionado : infoDelProducto!
    
    var contador = 0
    
    
    
    var ViewController: ViewController?
    
   
    @IBAction func añadir(_ sender: UIButton) {
        contador = contador + 1
        print(contador)
    }
    
   // override func prepare(for segue: UIStoryboardSegue, sender: Any?){
       // if contador = añadir.
        
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    view.backgroundColor = UIColor.red
        nombreProducto.text = selecionado.nombre
        precioProducto.text = String(selecionado.precio)
        imageSup.image = UIImage(named: selecionado.imagen)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
